//const SOCKET_PATH = 'http://localhost:3000';
//const PATH        = 'http://localhost:3000';
var SOCKET_PATH = 'http://80.73.81.154:3000';
var PATH = 'http://80.73.81.154:3000';
var socket = io(SOCKET_PATH);
var i18Msg = chrome.i18n.getMessage;
var alarmId = "repeatNotifications";
var alarmPeriod = 0.25;
function createRepeatNotificationAlarm() {
    chrome.alarms.clear(alarmId, function (wasCleared) {
        chrome.alarms.create(alarmId, {
            delayInMinutes: alarmPeriod
        });
    });
}
function createNotification(data) {
    var items = data.map(function (message) {
        return {
            title: i18Msg('from') + " " + message.addressee,
            message: "" + message.text.substr(0, 20) + (message.text.length > 20 ? "..." : "")
        };
    });
    chrome.notifications.create("new messages", {
        type: 'list',
        iconUrl: 'icons/icon48.png',
        title: i18Msg('titleNewMsg'),
        message: '',
        items: items,
        buttons: [
            {
                title: i18Msg('openButtonTitle'),
                iconUrl: 'icons/open_in_browser.png'
            }
        ],
    }, function (id) {
        createRepeatNotificationAlarm();
        chrome.tts.speak(i18Msg('ttsNewMessages'), { lang: 'ru' }, function () {
            if (chrome.runtime.lastError) {
                console.log('TTS Error: ' + chrome.runtime.lastError.message);
            }
        });
    });
}
function highlightWindow(windowId) {
    chrome.windows.update(windowId, { drawAttention: true });
}
function clearNotification(id) {
    chrome.notifications.clear(id);
}
function highlightTabs(notificationId, tabs) {
    chrome.tabs.highlight({ tabs: tabs.map(function (item) { return item.index; }) }, function () {
        highlightWindow(tabs[0].windowId);
        clearNotification(notificationId);
    });
}
function createTab(notificationId, windowId) {
    chrome.tabs.create({ url: "" + PATH, windowId: windowId }, function () {
        highlightWindow(windowId);
        clearNotification(notificationId);
    });
}
function createWindow(notificationId) {
    chrome.windows.create(function (window) {
        chrome.tabs.query({ windowId: window.id }, function (tabs) {
            if (tabs.length > 0) {
                chrome.tabs.update(tabs[0].id, { url: "" + PATH });
                highlightWindow(window.id);
            }
            else {
                createTab(notificationId, window.id);
            }
        });
    });
}
function activateTab(id, index) {
    if (id && index === 0) {
        chrome.tabs.query({ url: PATH + "/*" }, function (tabs) {
            if (tabs.length > 0) {
                highlightTabs(id, tabs);
            }
            else {
                chrome.windows.getAll(function (windows) {
                    if (windows.length > 0) {
                        createTab(id, windows[0].id);
                    }
                    else {
                        createWindow(id);
                    }
                });
            }
        });
    }
}
function connect() {
    chrome.browserAction.setIcon({ path: 'icons/icon19.png' });
    chrome.storage.sync.get('pin', function (item) {
        if (item && item.pin)
            socket.emit('ext online', { pin: item.pin });
    });
}
function disconnect() {
    chrome.browserAction.setIcon({ path: 'icons/icon19-.png' });
}
function onWindowMessage(data) {
    if (data.pin)
        chrome.storage.sync.set({ pin: data.pin }, function () {
            console.log('pin saved');
        });
}
function onAlarm(alarm) {
    if (alarm.name === alarmId) {
        chrome.storage.sync.get('pin', function (item) {
            if (item && item.pin)
                socket.emit('ext has new messages', { pin: item.pin });
        });
    }
}
function createNotificationNewMessages() {
    chrome.notifications.create("new messages", {
        type: 'basic',
        iconUrl: 'icons/icon48.png',
        title: i18Msg('titleNewMsg'),
        message: i18Msg('ttsNewMessagesRepeat'),
        buttons: [
            {
                title: i18Msg('openButtonTitle'),
                iconUrl: 'icons/open_in_browser.png'
            }
        ],
    }, function (id) {
        createRepeatNotificationAlarm();
        chrome.tts.speak(i18Msg('ttsNewMessagesRepeat'), { lang: 'ru' }, function () {
            if (chrome.runtime.lastError) {
                console.log('TTS Error: ' + chrome.runtime.lastError.message);
            }
        });
    });
}
socket.on('connect', connect);
socket.on('disconnect', disconnect);
socket.on('ext message', createNotification);
socket.on('ext has new messages', createNotificationNewMessages);
chrome.notifications.onButtonClicked.addListener(activateTab);
chrome.runtime.onMessage.addListener(onWindowMessage);
chrome.alarms.onAlarm.addListener(onAlarm);
chrome.browserAction.setIcon({ path: 'icons/icon19-.png' });
//# sourceMappingURL=background.js.map