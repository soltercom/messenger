//let SOCKET_PATH = 'http://localhost:3000';
//let PATH        = 'http://localhost:3000';
var SOCKET_PATH = 'http://Альтерком.РФ:3000';
var PATH = 'http://Альтерком.РФ:3000';
var socket = io(SOCKET_PATH);
function createNotification(items) {
    var titleNewMsg = chrome.i18n.getMessage('titleNewMsg');
    var openButtonTitle = chrome.i18n.getMessage('openButtonTitle');
    var closeButtonTitle = chrome.i18n.getMessage('closeButtonTitle');
    var notificationId = "new message";
    chrome.notifications.create(notificationId, {
        type: 'list',
        iconUrl: 'icons/icon48.png',
        title: titleNewMsg,
        message: '',
        items: items,
        buttons: [
            {
                title: openButtonTitle,
                iconUrl: 'icons/open_in_browser.png'
            }
        ],
        isClickable: true,
        requireInteraction: true
    });
}
function highlightWindow(windowId) {
    chrome.windows.update(windowId, { drawAttention: true });
}
function clearNotification(id) {
    chrome.notifications.clear(id);
}
function highlightTabs(notificationId, tabs) {
    chrome.tabs.highlight({ tabs: tabs.map(function (item) { return item.index; }) }, function () {
        highlightWindow(tabs[0].windowId);
        clearNotification(notificationId);
    });
}
function createTab(notificationId, windowId) {
    chrome.tabs.create({ url: "" + PATH, windowId: windowId }, function () {
        highlightWindow(windowId);
        clearNotification(notificationId);
    });
}
function createWindow(notificationId) {
    chrome.windows.create(function (window) {
        chrome.tabs.query({ windowId: window.id }, function (tabs) {
            if (tabs.length > 0) {
                chrome.tabs.update(tabs[0].id, { url: "" + PATH });
                highlightWindow(window.id);
            }
            else {
                createTab(notificationId, window.id);
            }
        });
    });
}
function connect() {
    chrome.storage.sync.get('pin', function (item) {
        if (item && item.pin)
            socket.emit('ext online', { pin: item.pin });
    });
}
socket.on('disconnect', function () {
    console.log('I am disconnected.');
});
socket.on('connect', function () {
    connect();
});
socket.on('ext message', function (data) {
    var from = chrome.i18n.getMessage('from');
    var items = data.map(function (message) {
        return {
            title: from + " " + message.addressee,
            message: "" + message.text.substr(0, 20) + (message.text.length > 20 ? "..." : "")
        };
    });
    createNotification(items);
});
chrome.notifications.onButtonClicked
    .addListener(function (id, index) {
    if (id && index === 0) {
        chrome.tabs.query({ url: PATH + "/*" }, function (tabs) {
            if (tabs.length > 0) {
                highlightTabs(id, tabs);
            }
            else {
                chrome.windows.getAll(function (windows) {
                    if (windows.length > 0) {
                        createTab(id, windows[0].id);
                    }
                    else {
                        createWindow(id);
                    }
                });
            }
        });
    }
});
chrome.runtime.onMessage
    .addListener(function (data) {
    if (data.pin)
        chrome.storage.sync.set({ pin: data.pin }, function () {
            console.log('pin saved');
        });
});
//# sourceMappingURL=background.js.map