var PATH2 = 'http://localhost:8080';
function open() {
    chrome.tabs.query({ url: PATH2 + "/*" }, function (tabs) {
        if (tabs.length > 0) {
            chrome.tabs.highlight({
                tabs: tabs.map(function (item) { return item.index; })
            }, null);
        }
        else {
            chrome.tabs.create({
                url: "" + PATH2
            });
        }
    });
}
function options() {
    chrome.runtime.openOptionsPage();
}
document.getElementById('open').addEventListener('click', open);
document.getElementById('options').addEventListener('click', options);
//# sourceMappingURL=popup.js.map