let PATH2 = 'http://localhost:8080';

function open() {
	chrome.tabs.query({ url: `${PATH2}/*` }, (tabs: chrome.tabs.Tab[]) => {
		if (tabs.length > 0) {
			chrome.tabs.highlight({
				tabs: tabs.map(item => item.index)
			}, null);
		} else {
			chrome.tabs.create({
				url: `${PATH2}`
			});
		}
	});

}

function options() {
	chrome.runtime.openOptionsPage();
}

document.getElementById('open').addEventListener('click', open);
document.getElementById('options').addEventListener('click', options);
