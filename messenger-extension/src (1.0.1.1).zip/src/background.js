//let SOCKET_PATH = 'http://localhost:3000';
//let PATH        = 'http://localhost:3000';
var SOCKET_PATH = 'http://Альтерком.РФ:3000';
var PATH = 'http://Альтерком.РФ:3000';
var socket = io(SOCKET_PATH);
function clearNotification(id) {
    chrome.notifications.clear(id);
}
function highlightTabs(notificationId, tabs) {
    chrome.tabs.highlight({ tabs: tabs.map(function (item) { return item.index; }) }, function () {
        clearNotification(notificationId);
    });
}
function createTab(notificationId, windowId) {
    chrome.tabs.create({ url: "" + PATH, windowId: windowId }, function () {
        clearNotification(notificationId);
    });
}
function createWindow(notificationId) {
    chrome.windows.create(function (window) {
        createTab(notificationId, window.id);
    });
}
chrome.storage.sync.get('pin', function (item) {
    if (item && item.pin)
        socket.emit('ext online', { pin: item.pin });
});
socket.on('ext message', function (data) {
    var titleNewMsg = chrome.i18n.getMessage('titleNewMsg');
    var from = chrome.i18n.getMessage('from');
    var openButtonTitle = chrome.i18n.getMessage('openButtonTitle');
    var closeButtonTitle = chrome.i18n.getMessage('closeButtonTitle');
    chrome.notifications.create(data.message.id, {
        type: 'basic',
        iconUrl: 'icons/icon128.png',
        title: titleNewMsg,
        message: from + " " + data.addressee,
        buttons: [
            {
                title: openButtonTitle,
                iconUrl: 'icons/open_in_browser.png'
            }
        ],
        requireInteraction: true
    });
    chrome.notifications.onButtonClicked
        .addListener(function (id, index) {
        if (id && index === 0) {
            chrome.tabs.query({ url: PATH + "/*" }, function (tabs) {
                if (tabs.length > 0) {
                    highlightTabs(id, tabs);
                }
                else {
                    chrome.windows.getAll(function (windows) {
                        if (windows.length > 0) {
                            createTab(id, windows[0].id);
                        }
                        else {
                            createWindow(id);
                        }
                    });
                }
            });
        }
    });
});
//# sourceMappingURL=background.js.map