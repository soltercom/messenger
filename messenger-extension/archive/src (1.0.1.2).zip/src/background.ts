//let SOCKET_PATH = 'http://localhost:3000';
//let PATH        = 'http://localhost:3000';
let SOCKET_PATH = 'http://Альтерком.РФ:3000';
let PATH = 'http://Альтерком.РФ:3000';

let socket = io(SOCKET_PATH);

function clearNotification(id: string) {
  chrome.notifications.clear(id);
}

function highlightTabs(notificationId: string, tabs: chrome.tabs.Tab[]) {
  chrome.tabs.highlight({tabs: tabs.map(item => item.index)}, () => {
    clearNotification(notificationId);
  });
}

function createTab(notificationId: string, windowId: number) {
  chrome.tabs.create({ url: `${PATH}`, windowId: windowId }, () => {
    clearNotification(notificationId);
  });
}

function createWindow(notificationId: string) {
  chrome.windows.create((window: chrome.windows.Window) => {
    createTab(notificationId, window.id);
  });
}

chrome.storage.sync.get('pin', (item: {pin: string}) => {
  if (item && item.pin) socket.emit('ext online', { pin: item.pin });
});

socket.on('ext message', (data: any) => {
  let titleNewMsg      = chrome.i18n.getMessage('titleNewMsg');
  let from             = chrome.i18n.getMessage('from');
  let openButtonTitle  = chrome.i18n.getMessage('openButtonTitle');
  let closeButtonTitle = chrome.i18n.getMessage('closeButtonTitle');
  chrome.notifications.create(data.message.id, {
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: titleNewMsg,
    message: `${from} ${data.addressee}`,
    buttons: [
      {
        title: openButtonTitle,
        iconUrl: 'icons/open_in_browser.png'
      }
    ],
    requireInteraction: true
  });
});

chrome.notifications.onButtonClicked
  .addListener((id: string, index: number) => {
    if (id && index === 0) {
      chrome.tabs.query({ url: `${PATH}/*` }, (tabs: chrome.tabs.Tab[]) => {
        if (tabs.length > 0) {
          highlightTabs(id, tabs);
        } else {
          chrome.windows.getAll((windows: chrome.windows.Window[]) => {
            if (windows.length > 0) {
              createTab(id, windows[0].id);
            } else {
              createWindow(id);
            }
          });
        }
      });
    }
  });
