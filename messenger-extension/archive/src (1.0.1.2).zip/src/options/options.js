function save() {
    var pin = document.getElementById('pin').value;
    chrome.storage.sync.set({
        pin: pin
    }, function () {
        chrome.runtime.reload();
    });
}
function restore() {
    chrome.storage.sync.get('pin', function (items) {
        document.getElementById('pin').value = items.pin || '';
    });
}
document.addEventListener('DOMContentLoaded', restore);
document.getElementById('save').addEventListener('click', save);
//# sourceMappingURL=options.js.map